﻿namespace Winform_ExcelWarning
{
    partial class ruleCon
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.bton_update = new System.Windows.Forms.Button();
            this.txtb_fileName = new System.Windows.Forms.TextBox();
            this.txtb_position = new System.Windows.Forms.TextBox();
            this.txtb_rule = new System.Windows.Forms.TextBox();
            this.txtb_describe = new System.Windows.Forms.TextBox();
            this.txtb_startTime = new System.Windows.Forms.TextBox();
            this.txtb_endTime = new System.Windows.Forms.TextBox();
            this.imag_state = new System.Windows.Forms.PictureBox();
            this.txtb_nextTime = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.imag_state)).BeginInit();
            this.SuspendLayout();
            // 
            // bton_update
            // 
            this.bton_update.Location = new System.Drawing.Point(721, 5);
            this.bton_update.Name = "bton_update";
            this.bton_update.Size = new System.Drawing.Size(46, 20);
            this.bton_update.TabIndex = 20;
            this.bton_update.Text = "修改";
            this.bton_update.UseVisualStyleBackColor = true;
            // 
            // txtb_fileName
            // 
            this.txtb_fileName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_fileName.Location = new System.Drawing.Point(3, 4);
            this.txtb_fileName.Name = "txtb_fileName";
            this.txtb_fileName.ReadOnly = true;
            this.txtb_fileName.Size = new System.Drawing.Size(100, 14);
            this.txtb_fileName.TabIndex = 21;
            // 
            // txtb_position
            // 
            this.txtb_position.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_position.Location = new System.Drawing.Point(127, 5);
            this.txtb_position.Name = "txtb_position";
            this.txtb_position.ReadOnly = true;
            this.txtb_position.Size = new System.Drawing.Size(53, 14);
            this.txtb_position.TabIndex = 22;
            this.txtb_position.TextChanged += new System.EventHandler(this.txtb_position_TextChanged);
            // 
            // txtb_rule
            // 
            this.txtb_rule.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_rule.Location = new System.Drawing.Point(203, 5);
            this.txtb_rule.Name = "txtb_rule";
            this.txtb_rule.ReadOnly = true;
            this.txtb_rule.Size = new System.Drawing.Size(53, 14);
            this.txtb_rule.TabIndex = 23;
            // 
            // txtb_describe
            // 
            this.txtb_describe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_describe.Location = new System.Drawing.Point(277, 6);
            this.txtb_describe.Name = "txtb_describe";
            this.txtb_describe.ReadOnly = true;
            this.txtb_describe.Size = new System.Drawing.Size(116, 14);
            this.txtb_describe.TabIndex = 24;
            // 
            // txtb_startTime
            // 
            this.txtb_startTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_startTime.Location = new System.Drawing.Point(403, 5);
            this.txtb_startTime.Name = "txtb_startTime";
            this.txtb_startTime.ReadOnly = true;
            this.txtb_startTime.Size = new System.Drawing.Size(73, 14);
            this.txtb_startTime.TabIndex = 25;
            // 
            // txtb_endTime
            // 
            this.txtb_endTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_endTime.Location = new System.Drawing.Point(515, 6);
            this.txtb_endTime.Name = "txtb_endTime";
            this.txtb_endTime.ReadOnly = true;
            this.txtb_endTime.Size = new System.Drawing.Size(73, 14);
            this.txtb_endTime.TabIndex = 26;
            // 
            // imag_state
            // 
            this.imag_state.Image = global::Winform_ExcelWarning.Properties.Resources._false;
            this.imag_state.Location = new System.Drawing.Point(797, 0);
            this.imag_state.Name = "imag_state";
            this.imag_state.Size = new System.Drawing.Size(28, 28);
            this.imag_state.TabIndex = 19;
            this.imag_state.TabStop = false;
            // 
            // txtb_nextTime
            // 
            this.txtb_nextTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_nextTime.Location = new System.Drawing.Point(630, 9);
            this.txtb_nextTime.Name = "txtb_nextTime";
            this.txtb_nextTime.ReadOnly = true;
            this.txtb_nextTime.Size = new System.Drawing.Size(73, 14);
            this.txtb_nextTime.TabIndex = 27;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(841, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(46, 20);
            this.button1.TabIndex = 28;
            this.button1.Text = "查看";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // ruleCon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtb_nextTime);
            this.Controls.Add(this.txtb_endTime);
            this.Controls.Add(this.txtb_startTime);
            this.Controls.Add(this.txtb_describe);
            this.Controls.Add(this.txtb_rule);
            this.Controls.Add(this.txtb_position);
            this.Controls.Add(this.txtb_fileName);
            this.Controls.Add(this.bton_update);
            this.Controls.Add(this.imag_state);
            this.Name = "ruleCon";
            this.Size = new System.Drawing.Size(890, 28);
            ((System.ComponentModel.ISupportInitialize)(this.imag_state)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.PictureBox imag_state;
        public System.Windows.Forms.Button bton_update;
        public System.Windows.Forms.TextBox txtb_fileName;
        public System.Windows.Forms.TextBox txtb_position;
        public System.Windows.Forms.TextBox txtb_rule;
        public System.Windows.Forms.TextBox txtb_describe;
        public System.Windows.Forms.TextBox txtb_startTime;
        public System.Windows.Forms.TextBox txtb_endTime;
        public System.Windows.Forms.TextBox txtb_nextTime;
        public System.Windows.Forms.Button button1;



    }
}

﻿namespace Winform_ExcelWarning
{
    partial class logCon
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtb_fileName = new System.Windows.Forms.TextBox();
            this.txtb_describe = new System.Windows.Forms.TextBox();
            this.txtb_startTime = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtb_fileName
            // 
            this.txtb_fileName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_fileName.Location = new System.Drawing.Point(3, 3);
            this.txtb_fileName.Name = "txtb_fileName";
            this.txtb_fileName.ReadOnly = true;
            this.txtb_fileName.Size = new System.Drawing.Size(100, 14);
            this.txtb_fileName.TabIndex = 22;
            // 
            // txtb_describe
            // 
            this.txtb_describe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_describe.Location = new System.Drawing.Point(115, 3);
            this.txtb_describe.Name = "txtb_describe";
            this.txtb_describe.ReadOnly = true;
            this.txtb_describe.Size = new System.Drawing.Size(160, 14);
            this.txtb_describe.TabIndex = 23;
            // 
            // txtb_startTime
            // 
            this.txtb_startTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_startTime.Location = new System.Drawing.Point(297, 3);
            this.txtb_startTime.Name = "txtb_startTime";
            this.txtb_startTime.ReadOnly = true;
            this.txtb_startTime.Size = new System.Drawing.Size(60, 14);
            this.txtb_startTime.TabIndex = 24;
            // 
            // logCon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtb_startTime);
            this.Controls.Add(this.txtb_describe);
            this.Controls.Add(this.txtb_fileName);
            this.Name = "logCon";
            this.Size = new System.Drawing.Size(360, 26);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txtb_fileName;
        public System.Windows.Forms.TextBox txtb_describe;
        public System.Windows.Forms.TextBox txtb_startTime;

    }
}
